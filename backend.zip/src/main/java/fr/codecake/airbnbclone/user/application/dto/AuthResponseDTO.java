package fr.codecake.airbnbclone.user.application.dto;

public record AuthResponseDTO(
        String token,
        String type,
        String username,
        String email
) {
    public AuthResponseDTO(String token, String username, String email) {
        this(token, "Bearer", username, email);
    }
}
