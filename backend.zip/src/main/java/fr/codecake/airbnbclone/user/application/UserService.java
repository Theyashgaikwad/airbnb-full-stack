package fr.codecake.airbnbclone.user.application;

import fr.codecake.airbnbclone.infrastructure.config.SecurityUtils;
import fr.codecake.airbnbclone.infrastructure.security.JwtTokenProvider;
import fr.codecake.airbnbclone.user.application.dto.AuthResponseDTO;
import fr.codecake.airbnbclone.user.application.dto.LoginDTO;
import fr.codecake.airbnbclone.user.application.dto.ReadUserDTO;
import fr.codecake.airbnbclone.user.application.dto.RegisterDTO;
import fr.codecake.airbnbclone.user.domain.Authority;
import fr.codecake.airbnbclone.user.domain.User;
import fr.codecake.airbnbclone.user.mapper.UserMapper;
import fr.codecake.airbnbclone.user.repository.AuthorityRepository;
import fr.codecake.airbnbclone.user.repository.UserRepository;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final AuthorityRepository authorityRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    public UserService(UserRepository userRepository, AuthorityRepository authorityRepository, UserMapper userMapper, 
                      PasswordEncoder passwordEncoder, JwtTokenProvider jwtTokenProvider) {
        this.userRepository = userRepository;
        this.authorityRepository = authorityRepository;
        this.userMapper = userMapper;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Transactional
    public AuthResponseDTO register(RegisterDTO registerDTO) {
        if (userRepository.findOneByEmail(registerDTO.email()).isPresent()) {
            throw new UserException("Email already registered");
        }

        User user = new User();
        user.setEmail(registerDTO.email());
        user.setFirstName(registerDTO.firstName());
        user.setLastName(registerDTO.lastName());
        user.setPassword(passwordEncoder.encode(registerDTO.password()));

        // Assign TENANT role - fetch or create if not exists
        Authority tenantRole = authorityRepository.findByName(SecurityUtils.ROLE_TENANT)
                .orElseGet(() -> {
                    Authority newRole = new Authority();
                    newRole.setName(SecurityUtils.ROLE_TENANT);
                    return authorityRepository.save(newRole);
                });
        user.setAuthorities(Set.of(tenantRole));

        User savedUser = userRepository.saveAndFlush(user);

        List<GrantedAuthority> authorities = getAuthorities(savedUser);
        String token = generateTokenForUser(savedUser.getEmail(), authorities);

        return new AuthResponseDTO(token, savedUser.getEmail(), savedUser.getEmail());
    }

    @Transactional(readOnly = true)
    public AuthResponseDTO login(LoginDTO loginDTO) {
        User user = userRepository.findOneByEmail(loginDTO.email())
                .orElseThrow(() -> new BadCredentialsException("Invalid email or password"));

        if (!passwordEncoder.matches(loginDTO.password(), user.getPassword())) {
            throw new BadCredentialsException("Invalid email or password");
        }

        List<GrantedAuthority> authorities = getAuthorities(user);
        String token = generateTokenForUser(user.getEmail(), authorities);

        return new AuthResponseDTO(token, user.getEmail(), user.getEmail());
    }

    @Transactional(readOnly = true)
    public ReadUserDTO getAuthenticatedUserFromSecurityContext() {
        String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        User user = userRepository.findOneByEmail(username)
                .orElseThrow(() -> new UserException("User not found"));
        return userMapper.readUserDTOToUser(user);
    }

    @Transactional(readOnly = true)
    public Optional<ReadUserDTO> getByEmail(String email) {
        Optional<User> oneByEmail = userRepository.findOneByEmail(email);
        return oneByEmail.map(userMapper::readUserDTOToUser);
    }

    @Transactional(readOnly = true)
    public Optional<ReadUserDTO> getByPublicId(UUID publicId) {
        Optional<User> oneByPublicId = userRepository.findOneByPublicId(publicId);
        return oneByPublicId.map(userMapper::readUserDTOToUser);
    }

    private String generateTokenForUser(String email, List<GrantedAuthority> authorities) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("roles", authorities);
        return jwtTokenProvider.generateToken(email, claims);
    }

    private List<GrantedAuthority> getAuthorities(User user) {
        return user.getAuthorities().stream()
                .map(authority -> (GrantedAuthority) new SimpleGrantedAuthority(authority.getName()))
                .toList();
    }
}
