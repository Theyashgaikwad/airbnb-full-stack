package fr.codecake.airbnbclone.sharedkernel.service;

public enum StatusNotification {
    OK, ERROR, UNAUTHORIZED;
}
