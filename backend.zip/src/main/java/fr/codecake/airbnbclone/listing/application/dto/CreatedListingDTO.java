package fr.codecake.airbnbclone.listing.application.dto;

public record CreatedListingDTO(String publicId) {
}
