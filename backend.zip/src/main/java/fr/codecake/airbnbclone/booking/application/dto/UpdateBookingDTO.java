package fr.codecake.airbnbclone.booking.application.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.time.OffsetDateTime;
import java.util.UUID;

public record UpdateBookingDTO(
        @NotNull UUID bookingPublicId,
        @NotNull OffsetDateTime startDate,
        @NotNull OffsetDateTime endDate,
        @Positive Integer numberOfTravelers,
        Integer totalPrice) {
}
