package fr.codecake.airbnbclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirbnbCloneBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirbnbCloneBackApplication.class, args);
	}

}
