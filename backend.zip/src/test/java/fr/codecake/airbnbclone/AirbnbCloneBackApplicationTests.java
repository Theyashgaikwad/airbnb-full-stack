package fr.codecake.airbnbclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirbnbCloneBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
