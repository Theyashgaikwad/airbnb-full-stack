import {Component, inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators, ReactiveFormsModule} from '@angular/forms';
import {DynamicDialogRef, DynamicDialogConfig} from 'primeng/dynamicdialog';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {InputMaskModule} from 'primeng/inputmask';
import {CommonModule, CurrencyPipe} from '@angular/common';
import {Router} from '@angular/router';
import {ToastService} from "../../layout/toast.service";

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    InputMaskModule,
    CommonModule,
    CurrencyPipe
  ],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.scss'
})
export class PaymentComponent implements OnInit {

  ref = inject(DynamicDialogRef);
  config = inject(DynamicDialogConfig);
  router = inject(Router);
  toastService = inject(ToastService);
  fb = inject(FormBuilder);

  totalAmount: number = 0;
  listingPublicId: string = '';

  paymentForm!: FormGroup;
  loading = false;

  ngOnInit() {
    this.initializeForm();
    this.receiveDialogData();
  }

  private receiveDialogData() {
    if (this.config.data) {
      this.totalAmount = this.config.data.totalAmount || 0;
      this.listingPublicId = this.config.data.listingPublicId || '';
    }
  }

  private initializeForm() {
    this.paymentForm = this.fb.group({
      cardholderName: ['', [Validators.required, Validators.minLength(3)]],
      cardNumber: ['', [Validators.required, Validators.minLength(16)]],
      expiryDate: ['', [Validators.required, Validators.minLength(5)]],
      cvv: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(4)]]
    });
  }

  onPayment() {
    if (this.paymentForm.invalid) {
      this.toastService.send({
        severity: "error",
        summary: "Validation Error",
        detail: "Please fill in all required fields correctly"
      });
      return;
    }

    this.loading = true;

    // Simulate payment processing
    setTimeout(() => {
      this.loading = false;
      this.ref.close({success: true});
      
      this.toastService.send({
        severity: "success",
        summary: "Payment Successful",
        detail: "Your booking has been confirmed!"
      });

      // Redirect to payment success page
      this.router.navigate(['/payment-success']);
    }, 2000);
  }

  onCancel() {
    this.ref.close({success: false});
  }

  get cardholderName() {
    return this.paymentForm.get('cardholderName');
  }

  get cardNumber() {
    return this.paymentForm.get('cardNumber');
  }

  get expiryDate() {
    return this.paymentForm.get('expiryDate');
  }

  get cvv() {
    return this.paymentForm.get('cvv');
  }
}
