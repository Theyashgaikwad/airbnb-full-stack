import {Component, inject} from '@angular/core';
import {Router} from '@angular/router';
import {FaIconComponent} from '@fortawesome/angular-fontawesome';
import {ButtonModule} from 'primeng/button';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [FaIconComponent, ButtonModule],
  templateUrl: './payment-success.component.html',
  styleUrl: './payment-success.component.scss'
})
export class PaymentSuccessComponent {
  
  router = inject(Router);
  bookingRef = this.generateBookingRef();

  onContinue() {
    this.router.navigate(['/booking']);
  }

  onBackHome() {
    this.router.navigate(['/']);
  }

  private generateBookingRef(): string {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  }
}
