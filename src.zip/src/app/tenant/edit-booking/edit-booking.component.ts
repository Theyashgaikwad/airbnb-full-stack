import {Component, effect, inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators, ReactiveFormsModule} from '@angular/forms';
import {DynamicDialogRef, DynamicDialogConfig} from 'primeng/dynamicdialog';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {InputNumberModule} from 'primeng/inputnumber';
import {CommonModule, CurrencyPipe} from '@angular/common';
import {Router} from '@angular/router';
import {ToastService} from "../../layout/toast.service";
import {BookingService} from "../service/booking.service";
import {CalendarModule} from "primeng/calendar";
import dayjs from "dayjs";
import {BookedListing, BookedDatesDTOFromClient} from "../model/booking.model";

@Component({
  selector: 'app-edit-booking',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    ButtonModule,
    InputTextModule,
    InputNumberModule,
    CommonModule,
    CurrencyPipe,
    CalendarModule
  ],
  templateUrl: './edit-booking.component.html',
  styleUrl: './edit-booking.component.scss'
})
export class EditBookingComponent implements OnInit {

  ref = inject(DynamicDialogRef);
  config = inject(DynamicDialogConfig);
  router = inject(Router);
  toastService = inject(ToastService);
  fb = inject(FormBuilder);
  bookingService = inject(BookingService);

  editForm!: FormGroup;
  loading = false;
  bookedListing: BookedListing | undefined;
  minDate = new Date();
  currentTotalPrice: number = 0;
  listingPrice: number = 0;
  private updateListener: any;

  constructor() {
    this.editForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      numberOfTravelers: [1, [Validators.required, Validators.min(1)]]
    });

    // Listen to update state changes in constructor (has injection context)
    this.updateListener = effect(() => {
      const updateState = this.bookingService.updateSig();
      if (updateState?.status === "OK") {
        this.loading = false;
        this.toastService.send({
          severity: "success",
          summary: "Success",
          detail: "Booking updated successfully"
        });
        this.ref.close({success: true});
      } else if (updateState?.status === "ERROR") {
        this.loading = false;
        const errorMsg = typeof updateState.error === 'string' ? updateState.error : "Failed to update booking";
        this.toastService.send({
          severity: "error",
          summary: "Error",
          detail: errorMsg
        });
      }
    });
  }

  ngOnInit() {
    this.initializeForm();
    this.receiveDialogData();
  }

  private receiveDialogData() {
    if (this.config.data) {
      this.bookedListing = this.config.data.bookedListing;
      this.listingPrice = this.config.data.listingPrice || 0;
      
      if (this.bookedListing) {
        this.currentTotalPrice = this.bookedListing.totalPrice.value;
        
        // Set dates in form
        const startDate = new Date(this.bookedListing.dates.startDate);
        const endDate = new Date(this.bookedListing.dates.endDate);
        
        this.editForm.patchValue({
          startDate: startDate,
          endDate: endDate,
          numberOfTravelers: 1
        });

        // Get booked dates for this listing
        this.bookingService.checkAvailability(this.bookedListing.listingPublicId);
      }
    }
  }

  private initializeForm() {
    this.editForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      numberOfTravelers: [1, [Validators.required, Validators.min(1)]]
    });

    // Listen for date changes to recalculate price
    this.editForm.get('startDate')?.valueChanges.subscribe(() => this.calculatePrice());
    this.editForm.get('endDate')?.valueChanges.subscribe(() => this.calculatePrice());
  }

  private calculatePrice() {
    const startDate = this.editForm.get('startDate')?.value;
    const endDate = this.editForm.get('endDate')?.value;

    if (startDate && endDate && startDate < endDate) {
      const startDayjs = dayjs(startDate);
      const endDayjs = dayjs(endDate);
      const nights = endDayjs.diff(startDayjs, 'days');
      this.currentTotalPrice = nights * this.listingPrice;
    } else {
      this.currentTotalPrice = 0;
    }
  }

  onUpdate() {
    if (this.editForm.invalid) {
      this.toastService.send({
        severity: "error",
        summary: "Validation Error",
        detail: "Please fill in all required fields"
      });
      return;
    }

    if (this.currentTotalPrice <= 0) {
      this.toastService.send({
        severity: "error",
        summary: "Invalid Dates",
        detail: "Please select valid dates (end date must be after start date)"
      });
      return;
    }

    if (!this.bookedListing) {
      return;
    }

    this.loading = true;

    const updateData = {
      bookingPublicId: this.bookedListing.bookingPublicId,
      startDate: this.editForm.get('startDate')?.value,
      endDate: this.editForm.get('endDate')?.value,
      numberOfTravelers: this.editForm.get('numberOfTravelers')?.value,
      totalPrice: this.currentTotalPrice
    };

    this.bookingService.update(updateData);
  }

  onCancel() {
    this.ref.close({success: false});
  }

  get startDate() {
    return this.editForm.get('startDate');
  }

  get endDate() {
    return this.editForm.get('endDate');
  }

  get numberOfTravelers() {
    return this.editForm.get('numberOfTravelers');
  }
}
