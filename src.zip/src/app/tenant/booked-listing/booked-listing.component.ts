import {Component, effect, inject, OnDestroy, OnInit} from '@angular/core';
import {BookingService} from "../service/booking.service";
import {ToastService} from "../../layout/toast.service";
import {BookedListing} from "../model/booking.model";
import {CardListingComponent} from "../../shared/card-listing/card-listing.component";
import {FaIconComponent} from "@fortawesome/angular-fontawesome";
import {DialogService, DynamicDialogRef} from "primeng/dynamicdialog";
import {EditBookingComponent} from "../edit-booking/edit-booking.component";

@Component({
  selector: 'app-booked-listing',
  standalone: true,
  imports: [
    CardListingComponent,
    FaIconComponent
  ],
  templateUrl: './booked-listing.component.html',
  styleUrl: './booked-listing.component.scss'
})
export class BookedListingComponent implements OnInit, OnDestroy {

  bookingService = inject(BookingService);
  toastService = inject(ToastService);
  dialogService = inject(DialogService);
  dialogRef: DynamicDialogRef | undefined;
  bookedListings = new Array<BookedListing>();

  loading = false;

  constructor() {
    this.listenFetchBooking();
    this.listenCancelBooking();
    this.listenUpdateBooking();
  }

  ngOnDestroy(): void {
    this.bookingService.resetCancel();
    this.dialogRef?.close();
  }

  ngOnInit(): void {
    this.fetchBooking();
  }

  private fetchBooking() {
    this.loading = true;
    this.bookingService.getBookedListing();
  }

  onCancelBooking(bookedListing: BookedListing) {
    bookedListing.loading = true;
    this.bookingService.cancel(bookedListing.bookingPublicId, bookedListing.listingPublicId, false);
  }

  onEditBooking(bookedListing: BookedListing) {
    // Calculate price per night from total price and date range
    const startDate = new Date(bookedListing.dates.startDate);
    const endDate = new Date(bookedListing.dates.endDate);
    const nights = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const pricePerNight = nights > 0 ? Math.round(bookedListing.totalPrice.value / nights) : 0;
    
    this.dialogRef = this.dialogService.open(EditBookingComponent, {
      header: 'Edit Booking',
      width: '50%',
      data: {
        bookedListing: bookedListing,
        listingPrice: pricePerNight
      }
    });
  }

  private listenFetchBooking() {
    effect(() => {
      const bookedListingsState = this.bookingService.getBookedListingSig();
      if (bookedListingsState.status === "OK") {
        this.loading = false;
        this.bookedListings = bookedListingsState.value!;
      } else if(bookedListingsState.status === "ERROR") {
        this.loading = false;
        this.toastService.send({
          severity: "error", summary: "Error when fetching the listing",
        });
      }
    });
  }

  private listenCancelBooking() {
    effect(() => {
      const cancelState = this.bookingService.cancelSig();
      if (cancelState.status === "OK") {
        const listingToDeleteIndex = this.bookedListings.findIndex(
          listing => listing.bookingPublicId === cancelState.value
        );
        this.bookedListings.splice(listingToDeleteIndex, 1);
        this.toastService.send({
          severity: "success", summary: "Successfully cancelled booking",
        });
      } else if (cancelState.status === "ERROR") {
        const listingToDeleteIndex = this.bookedListings.findIndex(
          listing => listing.bookingPublicId === cancelState.value
        );
        this.bookedListings[listingToDeleteIndex].loading = false;
        this.toastService.send({
          severity: "error", summary: "Error when cancel your booking",
        })
      }
    });
  }

  private listenUpdateBooking() {
    effect(() => {
      const updateState = this.bookingService.updateSig();
      if (updateState.status === "OK") {
        this.dialogRef?.close();
        this.toastService.send({
          severity: "success", summary: "Booking updated successfully",
        });
        this.fetchBooking();
      } else if (updateState.status === "ERROR") {
        this.toastService.send({
          severity: "error", summary: "Error updating booking",
        });
      }
    }, { allowSignalWrites: true });
  }
}
