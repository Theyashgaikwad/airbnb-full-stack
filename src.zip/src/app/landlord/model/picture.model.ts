export interface NewListingPicture {
  file: File,
  urlDisplay: string
}
