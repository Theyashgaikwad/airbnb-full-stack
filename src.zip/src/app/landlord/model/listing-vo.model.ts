export interface GuestsVO {
  value: number
}

export interface BedroomsVO {
  value: number
}

export interface BedsVO {
  value: number
}

export interface BathsVO {
  value: number
}

export interface TitleVO {
  value: string
}

export interface DescriptionVO {
  value: string
}

export interface PriceVO {
  value: number
}
