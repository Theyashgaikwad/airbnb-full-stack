import {Component, inject} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import {PasswordModule} from 'primeng/password';
import {TabViewModule} from 'primeng/tabview';
import {HttpClient} from '@angular/common/http';
import {DynamicDialogRef} from 'primeng/dynamicdialog';
import {environment} from '../../../environments/environment';
import {AuthService} from '../../core/auth/auth.service';

@Component({
  selector: 'app-login-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    InputTextModule,
    PasswordModule,
    TabViewModule
  ],
  templateUrl: './login-dialog.component.html',
  styleUrl: './login-dialog.component.scss'
})
export class LoginDialogComponent {
  http = inject(HttpClient);
  ref = inject(DynamicDialogRef);
  authService = inject(AuthService);

  // Login form
  loginEmail = '';
  loginPassword = '';
  loginLoading = false;

  // Register form
  registerEmail = '';
  registerPassword = '';
  registerFirstName = '';
  registerLastName = '';
  registerLoading = false;

  login(): void {
    if (!this.loginEmail || !this.loginPassword) {
      alert('Please enter email and password');
      return;
    }

    this.loginLoading = true;
    this.http.post<any>(`${environment.API_URL}/auth/login`, {
      email: this.loginEmail,
      password: this.loginPassword
    }).subscribe({
      next: (response) => {
        localStorage.setItem('authToken', response.token);
        this.authService.fetch(true);
        alert('Login successful');
        this.ref.close();
      },
      error: (err) => {
        this.loginLoading = false;
        alert('Error: ' + (err.error?.message || 'Login failed'));
      },
      complete: () => {
        this.loginLoading = false;
      }
    });
  }

  register(): void {
    if (!this.registerEmail || !this.registerPassword || !this.registerFirstName || !this.registerLastName) {
      alert('Please fill all fields');
      return;
    }

    this.registerLoading = true;
    this.http.post<any>(`${environment.API_URL}/auth/register`, {
      email: this.registerEmail,
      password: this.registerPassword,
      firstName: this.registerFirstName,
      lastName: this.registerLastName
    }).subscribe({
      next: (response) => {
        localStorage.setItem('authToken', response.token);
        this.authService.fetch(true);
        alert('Registration successful');
        this.ref.close();
      },
      error: (err) => {
        this.registerLoading = false;
        alert('Error: ' + (err.error?.message || 'Registration failed'));
      },
      complete: () => {
        this.registerLoading = false;
      }
    });
  }
}
