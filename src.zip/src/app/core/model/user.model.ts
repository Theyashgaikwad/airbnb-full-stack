export interface User {
  firstName?: string;
  lastName?: string;
  email?: string;
  imageUrl?: string;
  authorities?: string[];
}
