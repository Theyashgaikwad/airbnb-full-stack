export const environment = {
  API_URL: "//localhost:4200/api",
};
